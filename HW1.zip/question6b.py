import numpy as np
import networkx as nx
import matplotlib.pyplot as plt

# ▶ Εκτελεί pivot για το στοιχείο στη θέση (row, col)
def perform_pivot(mat, row, col):
    mat[row, :] /= mat[row, col]  # Κανονικοποίηση της pivot γραμμής
    for r in range(mat.shape[0]):
        if r != row:
            mat[r, :] -= mat[r, col] * mat[row, :]  # Μηδενισμός της στήλης του pivot για τις υπόλοιπες γραμμές
    return mat

# ▶ Επιστρέφει το κατάλληλο όνομα μεταβλητής (π.χ., x1, s2 κλπ)
def label_variable(index, total_vars):
    return f"x{index + 1}" if index < total_vars else f"s{index - total_vars + 1}"

# ▶ Δημιουργεί ένα μοναδικό "κλειδί" για το tableau (χρησιμοποιείται για τους κόμβους του γράφου)
def tableau_key(tb):
    return str(np.round(tb, 4).tolist())

# ▶ Αναλύει τη λύση: επιστρέφει τις τιμές των αρχικών μεταβλητών και τη τιμή Z
def parse_solution(tb, basic, total_vars):
    result = np.zeros(total_vars)
    for r, var_idx in enumerate(basic):
        if var_idx < total_vars:
            result[var_idx] = tb[r, -1]
    return result, tb[-1, -1]

# ▶ Εκτελεί τον Simplex ξεκινώντας από συγκεκριμένο pivot και κρατάει το ιστορικό για απεικόνιση σε γράφο
def simplex_with_tracking(c, A, b, initial_col):
    m, n = A.shape  # m: περιορισμοί, n: μεταβλητές
    identity = np.eye(m)  # Προσθήκη slack μεταβλητών
    tableau = np.hstack([A, identity, b[:, np.newaxis]])  # Κατασκευή πίνακα περιορισμών με slack και b
    cost_row = np.hstack([-c, np.zeros(m + 1)])  # Γραμμή στόχου (Z)
    tableau = np.vstack([tableau, cost_row])

    basis = list(range(n, n + m))  # Αρχικές βασικές μεταβλητές = slack μεταβλητές

    graph = nx.DiGraph()  # Δημιουργία γράφου για παρακολούθηση βημάτων
    labels = {}

    current_key = tableau_key(tableau)  # Το αρχικό tableau ως κόμβος
    graph.add_node(current_key)
    sol, z = parse_solution(tableau, basis, n)
    labels[current_key] = f"x={np.round(sol, 2)}\nZ={z:.2f}"  # Ετικέτα του κόμβου (λύση και τιμή Ζ)

    # ▶ Εσωτερική συνάρτηση: εκτελεί ένα pivot βήμα για συγκεκριμένη στήλη
    def pivot_step(tb, col, basis_vars):
        ratios = np.where(tb[:-1, col] > 0, tb[:-1, -1] / tb[:-1, col], np.inf)
        if np.all(ratios == np.inf):  # Αν δεν υπάρχουν θετικοί συντελεστές → πρόβλημα μη περιορισμένο
            return None, None, None
        row = np.argmin(ratios)
        out_var = basis_vars[row]
        tb = perform_pivot(tb, row, col)
        basis_vars[row] = col
        return tb, row, out_var

    # ▶ Πρώτο pivot σύμφωνα με το δοσμένο αρχικό column
    tableau, row, out_var = pivot_step(tableau, initial_col, basis)
    if tableau is None:
        return graph, labels  # Δεν προχωράει αν δεν είναι εφικτό

    # ▶ Καταγραφή του νέου tableau στον γράφο
    new_key = tableau_key(tableau)
    if new_key not in graph:
        graph.add_node(new_key)
        sol, z = parse_solution(tableau, basis, n)
        labels[new_key] = f"x={np.round(sol, 2)}\nZ={z:.2f}"
    graph.add_edge(current_key, new_key, label=f"{label_variable(out_var, n)} ↔ {label_variable(initial_col, n)}")
    current_key = new_key

    # ▶ Επανάληψη βημάτων Simplex μέχρι να μην υπάρχουν αρνητικά στη γραμμή Ζ
    while np.any(tableau[-1, :-1] < 0):
        next_col = np.argmin(tableau[-1, :-1])
        tableau, row, out_var = pivot_step(tableau, next_col, basis)
        if tableau is None:
            break
        new_key = tableau_key(tableau)
        if new_key not in graph:
            graph.add_node(new_key)
            sol, z = parse_solution(tableau, basis, n)
            labels[new_key] = f"x={np.round(sol, 2)}\nZ={z:.2f}"
        graph.add_edge(current_key, new_key, label=f"{label_variable(out_var, n)} ↔ {label_variable(next_col, n)}")
        current_key = new_key

    return graph, labels

# ▶ Οπτικοποιεί όλους τους γράφους για διαφορετικά αρχικά pivots
def visualize_graphs(graph_list, label_list):
    full_graph = nx.DiGraph()
    for g, lbl in zip(graph_list, label_list):
        full_graph.update(g)
        for node, text in lbl.items():
            full_graph.nodes[node]['label'] = text

    pos = nx.spring_layout(full_graph, seed=42)
    node_labels = nx.get_node_attributes(full_graph, 'label')
    edge_labels = nx.get_edge_attributes(full_graph, 'label')

    plt.figure(figsize=(16, 10))
    nx.draw(full_graph, pos, with_labels=True, labels=node_labels,
            node_color='lightgreen', node_size=3200,
            font_size=8, font_weight='bold')
    nx.draw_networkx_edge_labels(full_graph, pos, edge_labels=edge_labels, font_size=8)
    plt.title("Simplex Paths with Different Starting Pivots", fontsize=15)
    plt.axis('off')
    plt.show()

# ▪️ Ορισμός του γραμμικού προβλήματος
c_vec = np.array([2, 1, 6, -4])  # Συντελεστές αντικειμενικής συνάρτησης (Z)
A_mat = np.array([
    [1, 2, 4, -1],
    [2, 3, -1, 1],
    [1, 0, 1, 1]
])  # Πίνακας περιορισμών
b_vec = np.array([6, 12, 2])  # Δεξιά μέλη των περιορισμών

initial_pivots = [1, 0, 3, 2]  # Πιθανοί αρχικοί pivot για πειραματισμό
all_graphs = []
all_labels = []

# ▶ Εκτέλεση Simplex για κάθε αρχικό pivot
for first_col in initial_pivots:
    g, lbl = simplex_with_tracking(c_vec, A_mat, b_vec, initial_col=first_col)
    all_graphs.append(g)
    all_labels.append(lbl)

# ▶ Οπτικοποίηση όλων των διαδρομών
visualize_graphs(all_graphs, all_labels)
