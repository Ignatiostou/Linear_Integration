import numpy as np
from itertools import combinations

# Συνάρτηση για την επίλυση γραμμικού συστήματος Ax = b
def solve_system(A, b):
    try:
        x = np.linalg.solve(A, b)
        return x
    except np.linalg.LinAlgError:
        return None

# Συνάρτηση εφικτότητας (x ≥ 0)
def is_feasible(x, tol=1e-10):
    return x is not None and all(xi >= -tol for xi in x)

# Υπολογισμός Z = 8x1 + 5x2 + 4x3
def compute_Z(x):
    return 8*x[0] + 5*x[1] + 4*x[2] if x is not None else None

# Ορίζουμε το σύστημα εξισώσεων με slack/surplus variables
A_original = np.array([
    [1, 1, 0, -1, 0, 0, 0],   # x1 + x2 - s1 = 10
    [0, 1, 1, 0, -1, 0, 0],    # x2 + x3 - s2 = 15
    [1, 0, 1, 0, 0, -1, 0],    # x1 + x3 - s3 = 12
    [20, 10, 15, 0, 0, 0, 1]   # 20x1 + 10x2 + 15x3 + s4 = 300
])
b = np.array([10, 15, 12, 300])
variables = ['x1', 'x2', 'x3', 's1', 's2', 's3', 's4']

# Δημιουργία όλων των συνδυασμών 3 μη βασικών μεταβλητών (n - m = 3)
non_basic_combinations = list(combinations(range(7), 3))

basic_solutions = []
for non_basic_indices in non_basic_combinations:
    # Δημιουργία πίνακα A_basic (επιλογή στηλών που δεν ανήκουν στις μη βασικές)
    basic_indices = [i for i in range(7) if i not in non_basic_indices]
    A_basic = A_original[:, basic_indices]
    
    # Επίλυση για τις βασικές μεταβλητές
    x_basic = solve_system(A_basic, b)
    if x_basic is None:
        continue
    
    # Δημιουργία πλήρους λύσης (7 μεταβλητών)
    x_full = np.zeros(7)
    x_full[basic_indices] = x_basic
    x_full[list(non_basic_indices)] = 0  # Μη βασικές μεταβλητές = 0
    
    # Υπολογισμός Z (μόνο για x1, x2, x3)
    Z = compute_Z(x_full[:3]) if x_full is not None else None
    
    # Έλεγχος εφικτότητας και εκφυλισμού
    feasible = is_feasible(x_full)
    active_constraints = sum(abs(np.dot(A_original[i], x_full) - b[i]) < 1e-10 for i in range(4))
    degenerate = active_constraints > 4  # Εκφυλισμός αν > m ενεργοί περιορισμοί
    
    basic_solutions.append({
        'x': x_full,
        'Z': Z,
        'basic_vars': [variables[i] for i in basic_indices],
        'non_basic_vars': [variables[i] for i in non_basic_indices],
        'feasible': feasible,
        'degenerate': degenerate
    })

# Εκτύπωση όλων των βασικών λύσεων με Z
print("Όλες οι βασικές λύσεις (με Z):\n")
for i, sol in enumerate(basic_solutions, 1):
    print(f"Λύση {i}:")
    print(f" - Βασικές μεταβλητές: {sol['basic_vars']}")
    print(f" - Μη βασικές μεταβλητές: {sol['non_basic_vars']}")
    print(f" - x = {[f'{val:.2f}' for val in sol['x']]}")
    print(f" - Z = {sol['Z']:.2f}" if sol['Z'] is not None else " - Z = Undefined") 
    print(f" - Εφικτή; {'Ναι' if sol['feasible'] else 'Όχι'}")
    print(f" - Εκφυλισμένη; {'Ναι' if sol['degenerate'] else 'Όχι'}")
    print("-" * 50)

# Σύνοψη
feasible_solutions = [sol for sol in basic_solutions if sol['feasible']]
degenerate_solutions = [sol for sol in feasible_solutions if sol['degenerate']]

print(f"\nΣύνολο βασικών λύσεων: {len(basic_solutions)}")
print(f"Εφικτές βασικές λύσεις: {len(feasible_solutions)}")
print(f"Εκφυλισμένες βασικές λύσεις: {len(degenerate_solutions)}")