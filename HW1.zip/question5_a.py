import numpy as np
from itertools import combinations

# Συνάρτηση για την επίλυση γραμμικού συστήματος Ax = b
def solve_system(A, b):
    try:
        x = np.linalg.solve(A, b)
        return x
    except np.linalg.LinAlgError:
        return None

# Συνάρτηση για τον έλεγχο εφικτότητας (όλοι οι περιορισμοί)
def is_feasible(x, tol=1e-10):
    if x is None or any(xi < -tol for xi in x):  # Έλεγχος μη αρνητικότητας
        return False
    x1, x2, x3 = x
    # Έλεγχος όλων των περιορισμών
    c1 = (x1 + x2 >= 10 - tol)  # x1 + x2 ≥ 10
    c2 = (x2 + x3 >= 15 - tol)  # x2 + x3 ≥ 15
    c3 = (x1 + x3 >= 12 - tol)  # x1 + x3 ≥ 12
    c4 = (20*x1 + 10*x2 + 15*x3 <= 300 + tol)  # 20x1 + 10x2 + 15x3 ≤ 300
    return c1 and c2 and c3 and c4

# Υπολογισμός της αντικειμενικής συνάρτησης Z
def compute_Z(x):
    if x is None:
        return None
    return 8*x[0] + 5*x[1] + 4*x[2]

# Ορίζουμε όλους τους περιορισμούς ως εξισώσεις (Ax = b)
constraints_list = [
    {"name": "x1 + x2 ≥ 10", "A": [1, 1, 0], "b": 10, "type": "ineq"},
    {"name": "x2 + x3 ≥ 15", "A": [0, 1, 1], "b": 15, "type": "ineq"},
    {"name": "x1 + x3 ≥ 12", "A": [1, 0, 1], "b": 12, "type": "ineq"},
    {"name": "20x1 + 10x2 + 15x3 ≤ 300", "A": [20, 10, 15], "b": 300, "type": "ineq"},
    {"name": "x1 ≥ 0", "A": [1, 0, 0], "b": 0, "type": "nonneg"},
    {"name": "x2 ≥ 0", "A": [0, 1, 0], "b": 0, "type": "nonneg"},
    {"name": "x3 ≥ 0", "A": [0, 0, 1], "b": 0, "type": "nonneg"}
]

# Δημιουργούμε όλους τους συνδυασμούς 3 περιορισμών
all_combinations = list(combinations(constraints_list, 3))

# Εύρεση και έλεγχος όλων των κορυφών
results = []
for i, combo in enumerate(all_combinations, 1):
    # Δημιουργία πίνακα A και διανύσματος b
    A = np.array([c["A"] for c in combo])
    b = np.array([c["b"] for c in combo])
    x = solve_system(A, b)
    Z = compute_Z(x) if x is not None else None
    
    # Προετοιμασία αποτελέσματος
    result = {
        "combination": i,
        "constraints": [c["name"] for c in combo],
        "x": x,
        "Z": Z,
        "status": None,
        "active_constraints": []
    }
    
    if x is None:
        result["status"] = "Infeasible (no solution)"
    else:
        feasible = is_feasible(x)
        if feasible:
            # Έλεγχος για εκφυλισμό (περισσότεροι από 3 ενεργοί περιορισμοί)
            active_count = 0
            active_names = []
            for constraint in constraints_list:
                A_row = np.array(constraint["A"])
                b_val = constraint["b"]
                current_value = np.dot(A_row, x)
                # Έλεγχος αν ο περιορισμός ικανοποιείται ως ισότητα
                if constraint["type"] == "ineq":
                    if (">=" in constraint["name"] and abs(current_value - b_val) < 1e-10) or \
                       ("<=" in constraint["name"] and abs(current_value - b_val) < 1e-10):
                        active_count += 1
                        active_names.append(constraint["name"])
                elif constraint["type"] == "nonneg" and abs(x[np.where(A_row == 1)[0][0]]) < 1e-10:
                    active_count += 1
                    active_names.append(constraint["name"])
            
            result["active_constraints"] = active_names
            result["status"] = "Degenerate" if active_count > 3 else "Feasible"
        else:
            result["status"] = "Infeasible (violates constraints)"
    
    results.append(result)

# Εκτύπωση αποτελεσμάτων για όλους τους συνδυασμούς
print("Αναλυτικά αποτελέσματα για όλους τους 35 συνδυασμούς:\n")
for res in results:
    print(f"Συνδυασμός {res['combination']}:")
    print(f" - Περιορισμοί: {', '.join(res['constraints'])}")
    print(f" - Λύση x: {res['x']}")
    print(f" - Z = {res['Z'] if res['Z'] is not None else 'Undefined'}")
    print(f" - Κατάσταση: {res['status']}")
    if res['active_constraints']:
        print(f" - Ενεργοί περιορισμοί: {', '.join(res['active_constraints'])}")
    print("-" * 50)

# Σύνοψη εφικτών και εκφυλισμένων κορυφών
feasible_vertices = [res for res in results if res["status"] in ["Feasible", "Degenerate"]]
print("\nΣύνοψη εφικτών κορυφών:")
for i, v in enumerate(feasible_vertices, 1):
    print(f"\nΚορυφή {i}:")
    print(f" - x = {v['x']}")
    print(f" - Z = {v['Z']:.2f}")
    print(f" - Κατάσταση: {v['status']}")
    print(f" - Ενεργοί περιορισμοί: {', '.join(v['active_constraints'])}")

# Έλεγχος ύπαρξης εκφυλισμένων κορυφών
degenerate_exists = any(res["status"] == "Degenerate" for res in results)
print("\nΥπάρχουν εκφυλισμένες κορυφές;", "Ναι" if degenerate_exists else "Όχι")