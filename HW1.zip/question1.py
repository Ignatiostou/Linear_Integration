import numpy as np
import matplotlib.pyplot as plt
from itertools import combinations

# Ορισμός περιορισμών: [A, B, C, inequality]
constraints = [
    [6, 3, 12, '>='],  # Π1
    [4, 8, 16, '>='],  # Π2
    [6, 5, 30, '<='],  # Π3
    [6, 7, 36, '<='],  # Π4
    [1, 0, 0, '>='],   # x1 >= 0
    [0, 1, 0, '>=']    # x2 >= 0
]

# Βελτιωμένος έλεγχος εφικτότητας
def is_feasible(x1, x2, constraints, tol=1e-6):
    for A, B, C, ineq in constraints:
        value = A * x1 + B * x2
        if ineq == '>=' and value < C - tol:
            return False
        elif ineq == '<=' and value > C + tol:
            return False
    return True

# Συνάρτηση για εύρεση τομής ευθειών
def find_intersection(A1, B1, C1, A2, B2, C2):
    A = np.array([[A1, B1], [A2, B2]])
    b = np.array([C1, C2])
    try:
        x = np.linalg.solve(A, b)
        return x[0], x[1]
    except np.linalg.LinAlgError:
        return None

# Εύρεση κορυφών
vertices = []
for (i, (A1, B1, C1, ineq1)), (j, (A2, B2, C2, ineq2)) in combinations(enumerate(constraints), 2):
    point = find_intersection(A1, B1, C1, A2, B2, C2)
    if point is not None:
        x1, x2 = point
        if x1 >= -1e-6 and x2 >= -1e-6 and is_feasible(x1, x2, constraints):  # Αυστηρός έλεγχος
            vertices.append((x1, x2))

# Αφαίρεση διπλοτύπων και στρογγυλοποίηση
vertices = list(set([(round(x, 3), round(y, 3)) for (x, y) in vertices]))

# Τύπωση κορυφών
print("Κορυφές της εφικτής περιοχής:")
for i, (x1, x2) in enumerate(sorted(vertices), 1):
    print(f"{i}. ({x1:.2f}, {x2:.2f})")

# Σχεδίαση γραφήματος
plt.figure(figsize=(10, 8))
x1_vals = np.linspace(0, 6, 400)

# Συναρτήσεις περιορισμών
def constraint1(x1): return (12 - 6*x1)/3  # Π1
def constraint2(x1): return (16 - 4*x1)/8  # Π2
def constraint3(x1): return (30 - 6*x1)/5  # Π3
def constraint4(x1): return (36 - 6*x1)/7  # Π4

# Σχεδίαση περιορισμών
plt.plot(x1_vals, constraint1(x1_vals), label=r'$6x_1 + 3x_2 \geq 12$', color='blue')
plt.plot(x1_vals, constraint2(x1_vals), label=r'$4x_1 + 8x_2 \geq 16$', color='green')
plt.plot(x1_vals, constraint3(x1_vals), label=r'$6x_1 + 5x_2 \leq 30$', color='red')
plt.plot(x1_vals, constraint4(x1_vals), label=r'$6x_1 + 7x_2 \leq 36$', color='purple')

# Σχεδίαση γραμμών Z = 3x1 + x2 για Z = [0, 5, 10, 15, 20]
z_values = [0, 5, 10, 15, 20]
for z in z_values:
    x2_vals = z - 3 * x1_vals
    plt.plot(x1_vals, x2_vals, linestyle='--', label=f'$Z = {z}$')

# Σχεδίαση κορυφών
for x1, x2 in vertices:
    plt.plot(x1, x2, 'ro', markersize=8)
    plt.text(x1, x2, f'  ({x1:.2f}, {x2:.2f})', fontsize=9, va='bottom')

# Εφικτή περιοχή (ακριβής)
x2_lower = np.maximum(constraint1(x1_vals), constraint2(x1_vals))
x2_upper = np.minimum(constraint3(x1_vals), constraint4(x1_vals))
plt.fill_between(x1_vals, x2_lower, x2_upper, where=(x2_upper >= x2_lower), color='gray', alpha=0.3, label='Εφικτή περιοχή')

# Ρυθμίσεις
plt.xlim(0, 6)
plt.ylim(0, 7)
plt.xlabel(r'$x_1$', fontsize=12)
plt.ylabel(r'$x_2$', fontsize=12)
plt.title('Εφικτή Περιοχή, Κορυφές και Γραμμές Z', fontsize=14)
plt.legend(loc='upper right')
plt.grid(True)
plt.show()