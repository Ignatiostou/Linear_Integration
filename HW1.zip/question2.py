import numpy as np
import matplotlib.pyplot as plt

# Ορισμός των ευθειών των περιορισμών
x1 = np.linspace(0, 10, 100)

# Περιορισμός 1: 0.3x1 + 0.1x2 <= 2.7 → x2 = 27 - 3x1
x2_1 = 27 - 3 * x1

# Περιορισμός 2: 0.5x1 + 0.5x2 = 6 → x2 = 12 - x1
x2_2 = 12 - x1

# Περιορισμός 3: 0.6x1 + 0.4x2 >= 6 → x2 = 15 - 1.5x1
x2_3 = 15 - 1.5 * x1

# Σχεδίαση των ευθειών
plt.plot(x1, x2_1, label='Ευαίσθητοι ιστοί (≤ 2.7)', linestyle='--', color='blue')
plt.plot(x1, x2_2, label='Περιοχή όγκου (= 6)', linestyle='-', color='green')
plt.plot(x1, x2_3, label='Κέντρο μάζας (≥ 6)', linestyle=':', color='red')



# Σημεία τομής (ακραία σημεία της εφικτής περιοχής)
plt.scatter([6, 7.5], [6, 4.5], color='black', zorder=5)
plt.text(6, 6.2, '(6, 6)', fontsize=10)
plt.text(7.5, 4.7, '(7.5, 4.5)', fontsize=10)

# Διαμόρφωση γραφήματος
plt.xlabel('x1 (Δέσμη 1 - kilorads)')
plt.ylabel('x2 (Δέσμη 2 - kilorads)')
plt.title('Γραφική Λύση Προβλήματος Ακτινοθεραπείας')
plt.legend()
plt.grid(True)
plt.xlim(0, 10)
plt.ylim(0, 15)
plt.show()