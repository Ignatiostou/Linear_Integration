import numpy as np

# Συνάρτηση για την εκτύπωση του πίνακα Simplex με ωραία μορφή
def print_tableau(tableau, basic_vars, var_names):
    # Επικεφαλίδα πίνακα
    header = "| {:^5} ".format("B.V.")
    for name in var_names:
        header += "| {:^6} "
    header += "| {:^6} |"
    
    print("-" * len(header.format(*var_names, "b")))
    print(header.format(*var_names, "b"))
    print("-" * len(header.format(*var_names, "b")))

    # Εκτύπωση κάθε περιορισμού (γραμμή του πίνακα)
    for i in range(len(tableau) - 1):
        row = "| {:^5} ".format(basic_vars[i])
        for val in tableau[i, :-1]:
            row += "| {:6.2f} "
        row += "| {:6.2f} |"
        print(row.format(*tableau[i, :-1], tableau[i, -1]))

    # Εκτύπωση γραμμής στόχου (Z)
    print("-" * len(header.format(*var_names, "b")))
    row = "| {:^5} "
    for val in tableau[-1, :-1]:
        row += "| {:6.2f} "
    row += "| {:6.2f} |"
    print(row.format("Z", *tableau[-1, :-1], tableau[-1, -1]))
    print("-" * len(header.format(*var_names, "b")))
    print()

# Συνάρτηση που εκτελεί ένα βήμα του αλγορίθμου Simplex
def simplex_step(tableau, basic_vars, var_names):
    z_row = tableau[-1, :-1]  # Τελευταία γραμμή: συντελεστές της Z
    entering_idx = np.argmin(z_row)  # Εύρεση μεταβλητής που εισέρχεται (με το πιο αρνητικό συντελεστή)

    if z_row[entering_idx] >= 0:
        return False, None, None  # Αν δεν υπάρχουν αρνητικοί συντελεστές, έχουμε βέλτιστη λύση

    # Εύρεση μεταβλητής που εξέρχεται με βάση τον κανόνα του ελάχιστου λόγου
    rhs = tableau[:-1, -1]
    column = tableau[:-1, entering_idx]
    ratios = [rhs[i] / column[i] if column[i] > 0 else np.inf for i in range(len(rhs))]
    leaving_idx = np.argmin(ratios)

    pivot = tableau[leaving_idx, entering_idx]  # Pivot στοιχείο

    # Εκτυπώσεις για κατανόηση του τι συμβαίνει
    print(f"➡ Εισερχόμενη μεταβλητή: {var_names[entering_idx]}")
    print(f"➡ Εξερχόμενη μεταβλητή: {basic_vars[leaving_idx]}")
    print(f"➡ Pivot στοιχείο: {pivot:.3f}")
    print()

    # Κανονικοποίηση της γραμμής pivot
    tableau[leaving_idx] /= pivot

    # Μηδενισμός των άλλων στοιχείων στη στήλη της εισερχόμενης μεταβλητής
    for i in range(len(tableau)):
        if i != leaving_idx:
            factor = tableau[i, entering_idx]
            tableau[i] -= factor * tableau[leaving_idx]

    # Αντικατάσταση της εξερχόμενης μεταβλητής με την εισερχόμενη
    basic_vars[leaving_idx] = var_names[entering_idx]

    return True, basic_vars, tableau

# Κύρια συνάρτηση που εκτελεί τον Simplex
def run_simplex():
    # Ονόματα μεταβλητών (κανονικές + τεχνητές)
    var_names = ['x1', 'x2', 'x3', 'x4', 'x5', 'x6']
    basic_vars = ['x4', 'x5', 'x6']  # Αρχικές βασικές μεταβλητές (τεχνητές/slack)

    # Ο αρχικός πίνακας Simplex
    tableau = np.array([
        [1,  2,  4, 1, 0, 0,  6],   # περιορισμός 1
        [2,  3, -1, 0, 1, 0, 12],   # περιορισμός 2
        [1,  0,  1, 0, 0, 1,  2],   # περιορισμός 3
        [-2, -1, -6, 0, 0, 0,  0]   # συνάρτηση στόχου Z
    ], dtype=float)

    iteration = 0
    while True:
        print(f"\n🔁 Επανάληψη {iteration}")
        print_tableau(tableau, basic_vars, var_names)

        result = simplex_step(tableau, basic_vars, var_names)
        if not result[0]:
            print("✅ Η λύση είναι βέλτιστη!")
            break

        _, basic_vars, tableau = result
        iteration += 1

    # Εμφάνιση τελικής λύσης
    print("\n📌 Τελικές τιμές μεταβλητών:")
    final_values = {v: 0 for v in var_names}
    for i, var in enumerate(basic_vars):
        final_values[var] = tableau[i, -1]

    for var in var_names:
        print(f"{var} = {final_values[var]:.3f}")

    print(f"➡ Μέγιστο Z = {tableau[-1, -1]:.3f}")

# Εκκίνηση του αλγορίθμου
run_simplex()
