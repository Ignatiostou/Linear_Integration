import pulp

def define_model_and_solve():
    # --- Dual LP Model (with integer variables) ---
    model = pulp.LpProblem('Dual_Knapsack_LP', pulp.LpMinimize)

    # Variables: z0 for capacity constraint, z1–z5 for item upper bounds
    z = [pulp.LpVariable(f'z{i}', lowBound=0, cat='Integer') for i in range(6)]
    z0, z1, z2, z3, z4, z5 = z  # For easy reference

    # Objective function
    model += 11 * z0 + z1 + z2 + z3 + z4 + z5, 'Objective'

    # Constraints (one per primal variable)
    model += 2 * z0 + z1 >= 10  # item 1
    model += 3 * z0 + z2 >= 14  # item 2
    model += 4 * z0 + z3 >= 31  # item 3
    model += 6 * z0 + z4 >= 48  # item 4
    model += 8 * z0 + z5 >= 60  # item 5

    # Solve
    solver = pulp.PULP_CBC_CMD(msg=False)
    model.solve(solver)

    return model, z

def main():
    model, z = define_model_and_solve()

    # --- Results ---
    print('\n--- Dual Problem (Integer Solution) ---')
    print('\nStatus:', pulp.LpStatus[model.status])
    print(f'Optimal value Z = {pulp.value(model.objective):.3f}')

    print('\nVariable values:')
    print(', '.join([f'{var.name} = {var.varValue:.0f}' for var in model.variables()]))

if __name__ == "__main__":
    main()
