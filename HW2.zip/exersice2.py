from pulp import LpProblem, LpMaximize, LpVariable, LpStatus, value

# Δημιουργία του προβλήματος
prob = LpProblem("Dual_Problem_with_Slacks", LpMaximize)

# Ορισμός των μεταβλητών απόφασης
y1 = LpVariable("y1", upBound=0)  # y1 ≤0
y2 = LpVariable("y2")              # y2 ∈ ℝ (ελεύθερη μεταβλητή)
y3 = LpVariable("y3", lowBound=0)  # y3 ≥ 0

# Ορισμός της αντικειμενικής συνάρτησης (max w = 6y2 + 3y3)
prob += 6*y2 + 3*y3, "Objective"

# Προσθήκη των περιορισμών
prob += 2*y1 - y2 + 3*y3 >= 1, "Constraint_1"
prob += 3*y1 + y2 + y3 <= 1, "Constraint_2"
prob += y1 + 2*y2 + 4*y3 == 0, "Constraint_3"
prob += y1 + y2 + 2*y3 <= 0, "Constraint_4"

# Επίλυση του προβλήματος
prob.solve()

# Εκτύπωση των αποτελεσμάτων
print("Κατάσταση:", LpStatus[prob.status])
print("Βέλτιστη τιμή (w) =", value(prob.objective))
print("Βέλτιστες τιμές μεταβλητών:")
print(f"y1 = {value(y1)}")
print(f"y2 = {value(y2)}")
print(f"y3 = {value(y3)}\n")

# Υπολογισμός slack μεταβλητών
s1 = (2*value(y1) - value(y2) + 3*value(y3)) - 1  # Για Constraint_1 (≥)
s2 = 1 - (3*value(y1) + value(y2) + value(y3))    # Για Constraint_2 (≤)
s3 = 0 - (value(y1) + value(y2) + 2*value(y3))    # Για Constraint_4 (≤)

print("Slack μεταβλητές:")
print(f"Slack s1 (Constraint_1 ≥): {s1}")
print(f"Slack s2 (Constraint_2 ≤): {s2}")
print(f"Slack s3 (Constraint_4 ≤): {s3}\n")