import pulp

# Global state variables
best_objective_value = float('-inf')  # Best integer solution found (Global Lower Bound)
best_integer_solution = None          # Dictionary with the best integer variable values
node_counter = 0                      # Node identifier for debug output

solver = pulp.PULP_CBC_CMD(msg=False)  # Solver without output

# LP node solver function
def solve_lp_node(branch_constraints):
    model = pulp.LpProblem('BranchAndBoundLP', pulp.LpMaximize)

    # Decision variables
    variables = [pulp.LpVariable(f'x{i}', lowBound=0, cat='Continuous') for i in range(1, 4)]
    x1, x2, x3 = variables

    # Objective function
    model += 34 * x1 + 29 * x2 + 2 * x3

    # Constraints
    model += 7 * x1 + 5 * x2 -     x3 <= 16
    model +=    -x1 + 3 * x2 +     x3 <= 10
    model +=             -x2 + 2 * x3 <= 3

    # Apply branching constraints
    for (idx, op, val) in branch_constraints:
        if op == '<=':
            model += variables[idx - 1] <= val
        else:
            model += variables[idx - 1] >= val

    model.solve(solver)

    if pulp.LpStatus[model.status] == 'Optimal':
        Z = pulp.value(model.objective)
        solution = {v.name: v.varValue for v in model.variables()}
        return (Z, solution, True)
    else:
        return (float('-inf'), None, False)

# Recursive Branch & Bound
def branch_and_bound_recursive(parent_id, constraints, depth, max_depth=5):
    global best_objective_value, best_integer_solution, node_counter

    node_id = f'N{node_counter}'
    node_counter += 1

    Z, solution, feasible = solve_lp_node(constraints)

    print(f'\nNode {node_id} (Depth {depth}) - From: {parent_id or "ROOT"}')
    if not feasible:
        print('- Status: Infeasible — Discarded')
        return

    print(f'Objective Value: Z = {Z:.3f}')
    print('Variable Values: ' + ', '.join(f'{k}={v:.2f}' for k, v in sorted(solution.items(), key=lambda x: int(x[0][1:]))))

    if Z < best_objective_value:
        print(f'- Status: Bound (Z = {Z:.3f} < Current Best = {best_objective_value:.3f})')
        return

    var_idx, fractional_val = get_fractional_variable_info(solution)

    if var_idx is None:
        print('- Status: Integer solution')
        if Z > best_objective_value:
            best_objective_value = Z
            best_integer_solution = solution
            print(f'-> New best integer solution GUB = {best_objective_value:.3f}')
        return

    if depth >= max_depth:
        print(f'- Status: Max depth {max_depth} reached — TERMINATING')
        return

    print(f'- Status: Branching on x{var_idx} = {fractional_val:.3f}')

    floor_val = int(fractional_val)
    ceil_val = floor_val + 1

    # Branch 1: x <= floor
    branch_and_bound_recursive(
        node_id,
        constraints + [(var_idx, '<=', floor_val)],
        depth + 1,
        max_depth
    )

    # Branch 2: x >= ceil
    branch_and_bound_recursive(
        node_id,
        constraints + [(var_idx, '>=', ceil_val)],
        depth + 1,
        max_depth
    )

# Utility to find first fractional variable
def get_fractional_variable_info(solution_dict):
    for i in range(1, 4):
        var_name = f'x{i}'
        val = solution_dict.get(var_name, 0.)
        if abs(val - round(val)) > 1e-5:
            return (i, val)
    return (None, None)

def main():
    global best_objective_value, best_integer_solution, node_counter

    best_objective_value = float('-inf')
    best_integer_solution = None
    node_counter = 0

    
    branch_and_bound_recursive(None, [], 0, max_depth=20)

    print('\n--- Final Result')
    if best_integer_solution:
        sorted_vars = sorted(best_integer_solution.items(), key=lambda x: int(x[0][1:]))
        print(f'Best Integer Solution: Z = {best_objective_value:.0f}')
        print('x = {' + ', '.join(f'{k} = {v:.0f}' for k, v in sorted_vars) + '}')
    else:
        print('No integer solution found.')

if __name__ == '__main__':
    main()
