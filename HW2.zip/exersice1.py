import pulp

print("=== ΛΥΣΗ ΠΡΩΤΕΥΟΝΤΟΣ ===")
# Πρωτεύον πρόβλημα (Maximization)
primal = pulp.LpProblem("Primal", pulp.LpMaximize)

# Μεταβλητές: x1 ∈ R, x2..x5 ≥ 0
x1 = pulp.LpVariable("x1", lowBound=None)
x2 = pulp.LpVariable("x2", lowBound=0)
x3 = pulp.LpVariable("x3", lowBound=0)
x4 = pulp.LpVariable("x4", lowBound=0)
x5 = pulp.LpVariable("x5", lowBound=0)

# Αντικειμενική
primal += 3*x1 + 11*x2 + 9*x3 - x4 - 29*x5

# Περιορισμοί
primal += x2 + x3 + x4 - 2*x5 <= 4, "p1"
primal += x1 - x2 + x3 + 2*x4 + x5 >= 0, "p2"
primal += x1 + x2 + x3 - 3*x5 <= 1, "p3"

# Επίλυση
primal.solve()
print("Κατάσταση:", pulp.LpStatus[primal.status])
print("Βέλτιστη τιμή:", pulp.value(primal.objective))

# Τιμές primal μεταβλητών
primal_vars = {}
for v in primal.variables():
    print(f"{v.name} = {v.varValue}")
    primal_vars[v.name] = v.varValue

# Slack περιορισμών primal
primal_slacks = {}
for name, constraint in primal.constraints.items():
    slack = constraint.slack
    print(f"Slack {name} = {slack}")
    primal_slacks[name] = slack


print("\n=== ΛΥΣΗ ΔΥΪΚΟΥ ===")
# Δυϊκό πρόβλημα (Minimization)
dual = pulp.LpProblem("Dual", pulp.LpMinimize)

# Δυϊκές μεταβλητές
y1 = pulp.LpVariable("y1", lowBound=0)
y2 = pulp.LpVariable("y2", upBound=0)
y3 = pulp.LpVariable("y3", lowBound=0)

# Αντικειμενική
dual += 4*y1 + 0*y2 + 1*y3

# Περιορισμοί dual
dual += y2 + y3 == 3, "d1"                   # x1
dual += y1 - y2 + y3 >= 11, "d2"             # x2
dual += y1 + y2 + y3 >= 9, "d3"              # x3
dual += y1 + 2*y2 >= -1, "d4"                # x4
dual += -2*y1 + y2 - 3*y3 >= -29, "d5"       # x5

# Επίλυση
dual.solve()
print("Κατάσταση:", pulp.LpStatus[dual.status])
print("Βέλτιστη τιμή:", pulp.value(dual.objective))

# Τιμές dual μεταβλητών
dual_vars = {}
for v in dual.variables():
    print(f"{v.name} = {v.varValue}")
    dual_vars[v.name] = v.varValue

# Slack περιορισμών dual
dual_slacks = {}
for name, constraint in dual.constraints.items():
    slack = constraint.slack
    print(f"Slack {name} = {slack}")
    dual_slacks[name] = slack


# ================================================
# ΕΛΕΓΧΟΣ ΣΥΜΠΛΗΡΩΜΑΤΙΚΗΣ ΧΑΛΑΡΟΤΗΤΑΣ
# ================================================
print("\n=== ΕΛΕΓΧΟΣ ΣΥΜΠΛΗΡΩΜΑΤΙΚΗΣ ΧΑΛΑΡΟΤΗΤΑΣ ===")

# Αν xj > 0 ⇒ αντίστοιχος dual περιορισμός δεσμευτικός ⇒ slack = 0
for i, (xname, xval) in enumerate(primal_vars.items()):
    dname = f"d{i+1}" if xname != "x1" else "d1"  # x1 αντιστοιχεί στο d1 (εξίσωση)
    dslack = dual_slacks.get(dname, None)
    if xval > 1e-6:
        print(f"{xname} > 0 ⇒ dual περιορισμός {dname} πρέπει να είναι δεσμευτικός ⇒ slack = {dslack}")
        assert abs(dslack) < 1e-6, f"❌ Παραβίαση CSC: {xname} > 0 αλλά slack {dslack} ≠ 0"
    else:
        print(f"{xname} = 0 ⇒ δεν απαιτείται κάτι για το dual περιορισμό {dname}")

# Αν yi ≠ 0 ⇒ αντίστοιχος primal περιορισμός δεσμευτικός ⇒ slack = 0
for i, (yname, yval) in enumerate(dual_vars.items()):
    pname = f"p{i+1}"
    pslack = primal_slacks.get(pname, None)
    if abs(yval) > 1e-6:
        print(f"{yname} ≠ 0 ⇒ primal περιορισμός {pname} πρέπει να είναι δεσμευτικός ⇒ slack = {pslack}")
        assert abs(pslack) < 1e-6, f"❌ Παραβίαση CSC: {yname} ≠ 0 αλλά slack {pslack} ≠ 0"
    else:
        print(f"{yname} = 0 ⇒ δεν απαιτείται κάτι για τον primal περιορισμό {pname}")
