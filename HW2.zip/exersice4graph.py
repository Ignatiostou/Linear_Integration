import pulp

# Καθολικές μεταβλητές για την καλύτερη ακέραια λύση
optimal_objective_value = float('inf')  # Παγκόσμιο ανώτατο όριο
optimal_integer_solution = None         # Καλύτερη γνωστή ακέραια λύση
node_counter = 0                        # Μετρητής κόμβων για εντοπισμό

# Ορισμός του επιλυτή (χωρίς μηνύματα στην έξοδο)
solver = pulp.PULP_CBC_CMD(msg=False)

# Επίλυση LP για συγκεκριμένους περιορισμούς διακλάδωσης
def solve_lp_node(branching_constraints):
    model = pulp.LpProblem('Waiter_Scheduling_LP_Node', pulp.LpMinimize)

    # Δημιουργία μεταβλητών απόφασης
    decision_vars = [pulp.LpVariable(f'x{i}', lowBound=0, cat='Continuous') for i in range(1, 8)]
    (x1, x2, x3, x4, x5, x6, x7) = decision_vars

    # Αντικειμενική συνάρτηση: ελαχιστοποίηση συνολικών εργαζομένων
    model += pulp.lpSum(decision_vars)

    # Περιορισμοί κάλυψης για κάθε ημέρα
    model += x1           + x4 + x5 + x6 + x7 >= 8  # Δευτέρα
    model += x1 + x2           + x5 + x6 + x7 >= 8  # Τρίτη
    model += x1 + x2 + x3           + x6 + x7 >= 8  # Τετάρτη
    model += x1 + x2 + x3 + x4           + x7 >= 8  # Πέμπτη
    model += x1 + x2 + x3 + x4 + x5           >= 15 # Παρασκευή
    model +=      x2 + x3 + x4 + x5 + x6      >= 15 # Σάββατο
    model +=           x3 + x4 + x5 + x6 + x7 >= 10 # Κυριακή

    # Προσθήκη περιορισμών διακλάδωσης
    for (index, operator, value) in branching_constraints:
        if operator == '<=':
            model += decision_vars[index - 1] <= value
        else:
            model += decision_vars[index - 1] >= value

    # Εκτέλεση επίλυσης LP
    model.solve(solver)

    if pulp.LpStatus[model.status] == 'Optimal':
        Z = pulp.value(model.objective)
        solution = {v.name: v.varValue for v in model.variables()}
        return (Z, solution, True)
    else:
        return (float('inf'), None, False)

# Αναδρομική εφαρμογή Branch & Bound
def branch_and_bound_recursive(parent_id, constraints, depth, max_depth=5):
    global optimal_objective_value, optimal_integer_solution, node_counter

    node_id = f'N{node_counter}'
    node_counter += 1

    (Z, solution, is_feasible) = solve_lp_node(constraints)

    print(f'\nΚόμβος {node_id} (Επίπεδο {depth}) - Προηγούμενος: {parent_id or "ROOT"}')

    if not is_feasible:
        print('- Κατάσταση: Μη εφικτό — Απορρίπτεται')
        return

    print(f'Τρέχουσα τιμή στόχου: Z = {Z:.3f}')
    print('Λύση: ' + ', '.join(f'{k}={v:.2f}' for (k, v) in sorted(solution.items(), key=lambda x: int(x[0][1:]))))

    if Z > optimal_objective_value:
        print(f'- Κατάσταση: Υπέρβαση ορίου (Z = {Z:.3f} > GUB = {optimal_objective_value:.3f})')
        return

    (fractional_index, fractional_value) = get_fractional_variable_info(solution)

    if fractional_index is None:
        print('- Κατάσταση: Ακέραιη λύση')
        if Z < optimal_objective_value:
            optimal_objective_value = Z
            optimal_integer_solution = solution
            print(f'-> Νέα βέλτιστη λύση. GUB = {optimal_objective_value:.3f}')
        return

    if depth >= max_depth:
        print(f'- Κατάσταση: Μέγιστο βάθος {max_depth} — Διακοπή')
        return

    print(f'- Διαχωρισμός μεταβλητής x{fractional_index} = {fractional_value:.3f}')

    floor_val = int(fractional_value)
    ceil_val = floor_val + 1

    # Κλήση για υποκλάδο με περιορισμό x ≤ floor
    branch_and_bound_recursive(
        node_id,
        constraints + [(fractional_index, '<=', floor_val)],
        depth + 1,
        max_depth
    )

    # Κλήση για υποκλάδο με περιορισμό x ≥ ceil
    branch_and_bound_recursive(
        node_id,
        constraints + [(fractional_index, '>=', ceil_val)],
        depth + 1,
        max_depth
    )

# Εύρεση πρώτης μη ακέραιας μεταβλητής
def get_fractional_variable_info(solution_dict):
    for i in range(1, 8):
        var = f'x{i}'
        val = solution_dict.get(var, 0.0)
        if abs(val - round(val)) > 1e-5:
            return (i, val)
    return (None, None)

# Κύρια συνάρτηση
def main():
    global optimal_objective_value, optimal_integer_solution, node_counter

    optimal_objective_value = float('inf')
    optimal_integer_solution = None
    node_counter = 0

    
    branch_and_bound_recursive(None, [], 0, max_depth=3)

    print('\n--- Τελικό Αποτέλεσμα ---')
    if optimal_integer_solution:
        sorted_solution = sorted(optimal_integer_solution.items(), key=lambda x: int(x[0][1:]))
        print(f'Βέλτιστη τιμή στόχου: Z = {optimal_objective_value:.0f}')
        print('x = {' + ', '.join(f'{k} = {v:.0f}' for (k, v) in sorted_solution) + '}')
    else:
        print('Δεν βρέθηκε ακέραια λύση.')

if __name__ == '__main__':
    main()
