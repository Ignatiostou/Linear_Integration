import pulp

# Δημιουργία προβλήματος
lp_problem = pulp.LpProblem("Maximize_Objective", pulp.LpMaximize)

# Μεταβλητές
x1 = pulp.LpVariable("x1", lowBound=None)
x2 = pulp.LpVariable("x2", lowBound=0)
x3 = pulp.LpVariable("x3", lowBound=0)
x4 = pulp.LpVariable("x4", lowBound=0)
x5 = pulp.LpVariable("x5", lowBound=0)

# Αντικειμενική συνάρτηση
lp_problem += 3*x1 + 11*x2 + 9*x3 - x4 - 29*x5

# Περιορισμοί
constr1 = x2 + x3 + x4 - 2*x5 <= 4      # s1
constr2 = x1 - x2 + x3 + 2*x4 + x5 >= 0 # s2
constr3 = x1 + x2 + x3 - 3*x5 <= 1      # s3

lp_problem += constr1
lp_problem += constr2
lp_problem += constr3

# Επίλυση
lp_problem.solve()

# Εκτύπωση λύσης
print(f"Κατάσταση: {pulp.LpStatus[lp_problem.status]}")
print(f"x1 = {x1.varValue}")
print(f"x2 = {x2.varValue}")
print(f"x3 = {x3.varValue}")
print(f"x4 = {x4.varValue}")
print(f"x5 = {x5.varValue}")
print(f"Μέγιστο z = {pulp.value(lp_problem.objective)}")

# Υπολογισμός μεταβλητών χαλάρωσης (slack ή surplus)
s1 = 4 - (x2.varValue + x3.varValue + x4.varValue - 2*x5.varValue)        # <= 4
s2 = (x1.varValue - x2.varValue + x3.varValue + 2*x4.varValue + x5.varValue) - 0  # >= 0
s3 = 1 - (x1.varValue + x2.varValue + x3.varValue - 3*x5.varValue)        # <= 1

print(f"s1 (slack of constraint 1) = {s1}")
print(f"s2 (surplus of constraint 2) = {s2}")
print(f"s3 (slack of constraint 3) = {s3}")
