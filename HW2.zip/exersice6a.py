import pulp

# Global state variables
best_integer_obj = float('-inf')      # Global Upper Bound (GUB) for integer solutions
best_integer_sol = None               # Best integer solution found
node_counter     = 0                  # Node ID tracker for debugging

solver = pulp.PULP_CBC_CMD(msg=False) # Solver with no output messages

# Solves LP relaxation at a given node with specific branching constraints
def solve_lp_node(branch_constraints):
    model = pulp.LpProblem('BranchAndBoundLP', pulp.LpMaximize)

    # Decision variables (continuous in relaxation)
    x1 = pulp.LpVariable('x1', lowBound=0, upBound=1, cat='Continuous')
    x2 = pulp.LpVariable('x2', lowBound=0, upBound=1, cat='Continuous')
    x3 = pulp.LpVariable('x3', lowBound=0, upBound=1, cat='Continuous')
    x4 = pulp.LpVariable('x4', lowBound=0, upBound=1, cat='Continuous')
    x5 = pulp.LpVariable('x5', lowBound=0, upBound=1, cat='Continuous')
    x = [x1, x2, x3, x4, x5]  # Variable list for indexing

    # Objective function: maximize profit
    model += (
        10 * x1 + 14 * x2 + 31 * x3 + 48 * x4 + 60 * x5,
        'Objective'
    )

    # Capacity constraint
    model += 2 * x1 + 3 * x2 + 4 * x3 + 6 * x4 + 8 * x5 <= 11

    # Apply branching constraints
    for (idx, op, val) in branch_constraints:
        if op == '<=':
            model += x[idx - 1] <= val
        else:
            model += x[idx - 1] >= val

    model.solve(solver)

    if pulp.LpStatus[model.status] == 'Optimal':
        objective_value = pulp.value(model.objective)
        variable_values = {v.name: v.varValue for v in model.variables()}
        return (objective_value, variable_values, True)
    else:
        return (float('-inf'), None, False)

# Recursive Branch & Bound implementation
def branch_and_bound_recursive(
    parent_id, constraints, depth, max_depth=5
):
    global best_integer_obj, best_integer_sol, node_counter

    current_node_id = f'N{node_counter}'
    node_counter += 1

    (obj_value, solution, feasible) = solve_lp_node(constraints)

    print(f'\nNode {current_node_id} (Depth {depth})', end=' - ')
    print(f'Parent: {parent_id or "ROOT"}')
    if not feasible:
        print('- Status: Infeasible — Pruned')
        return

    print(f'Objective value: Z = {obj_value:.3f}')
    print('Variable values: ' + ', '.join(
        f'{k}={v:.2f}' for (k, v) in sorted(
            solution.items(), key=lambda x: int(x[0][1:])
        )
    ))

    if obj_value < best_integer_obj:
        print(f'- Status: Bound (Z = {obj_value:.3f} < GUB = {best_integer_obj:.3f})')
        return

    (fractional_index, fractional_value) = get_first_fractional_variable(solution)

    if fractional_index is None:
        print('- Status: Integer solution')
        if obj_value > best_integer_obj:
            best_integer_obj = obj_value
            best_integer_sol = solution
            print(f'-> New best integer solution GUB = {best_integer_obj:.3f}')
        return

    if depth >= max_depth:
        print(f'- Status: Max depth {max_depth} reached — TERMINATING')
        return

    print(f'- Status: Branch on x{fractional_index} = {fractional_value:.3f}')

    floor_value = int(fractional_value)
    ceil_value = floor_value + 1

    # Branch 1: x_i <= floor_value
    branch_and_bound_recursive(
        current_node_id,
        constraints + [(fractional_index, '<=', floor_value)],
        depth + 1,
        max_depth
    )

    # Branch 2: x_i >= ceil_value
    branch_and_bound_recursive(
        current_node_id,
        constraints + [(fractional_index, '>=', ceil_value)],
        depth + 1,
        max_depth
    )

    return

# Utility to find the first non-integer variable in the LP solution
def get_first_fractional_variable(solution_dict):
    for i in range(1, 6):
        var = f'x{i}'
        val = solution_dict.get(var, 0.)
        if abs(val - round(val)) > 1e-5:
            return (i, val)
    return (None, None)

# Main entry point
def main():
    global best_integer_obj, best_integer_sol, node_counter

    best_integer_obj = float('-inf')
    best_integer_sol = None
    node_counter = 0

    
    branch_and_bound_recursive(None, [], 0, max_depth=20)

    print('\n--- Final Result ---')
    if best_integer_sol:
        sorted_vars = sorted(
            best_integer_sol.items(), key=lambda x: int(x[0][1:])
        )
        print(f'Best integer solution: Z = {best_integer_obj:.0f}')
        print('x = {' + ', '.join(f'{k} = {v:.0f}' for (k, v) in sorted_vars) + '}')
    else:
        print('No integer solution found.')

    return

if __name__ == '__main__':
    main()
