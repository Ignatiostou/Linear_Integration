# -*- coding: utf-8 -*-
import pulp
from itertools import product
from random import shuffle, random
import pandas as pd
from collections import defaultdict
import time

# ----------------------------
# Δεδομένα (Ομάδες, τηλεοπτικά κανάλια, κοινά γήπεδα)
# ----------------------------

teams = [
    "Barcelona", "Real Madrid",
    "Liverpool", "Man City", "Man United", "Arsenal",
    "Inter", "Milan",
    "AEK", "Panathinaikos",
    "Red Star", "Partizan",
    "Chelsea", "Bayern", "Dortmund", "Juventus", "PSG", "Benfica", "Marseille", "Porto"
]

# Αντιστοίχιση ομάδων σε τηλεοπτικά κανάλια
cosmote_teams = [
    "Barcelona", "Real Madrid", "Liverpool", "Man City", "Man United", "Arsenal",
    "Chelsea", "Bayern", "Juventus", "PSG"
]

nova_teams = [
    "Inter", "Milan", "AEK", "Panathinaikos", "Red Star", "Partizan",
    "Dortmund", "Benfica", "Porto", "Marseille"
]

# Ζευγάρια ομάδων που μοιράζονται το ίδιο γήπεδο
shared_stadium_pairs = [
    ("AEK", "Panathinaikos"),
    ("Inter", "Milan"),
    ("Red Star", "Partizan"),
    ("Benfica", "Porto"),
    ("Chelsea", "Arsenal")
]

seeded_teams = ["Barcelona", "Porto", "Panathinaikos", "Liverpool"]

n_teams = len(teams)
n_rounds = 2 * (n_teams - 1)

# ----------------------------
# Βοηθητικές Συναρτήσεις
# ----------------------------

# Υπολογισμός breaks (αλλαγές από Εντός σε Εκτός ή το αντίστροφο)
def count_breaks(pattern):
    return sum(1 for i in range(len(pattern) - 1) if pattern[i] == pattern[i+1])

# Συμπλήρωμα ενός pattern (αντιστρέφει H <-> A)
def complement_pattern(pattern):
    return ''.join('H' if c == 'A' else 'A' for c in pattern)

# Δημιουργία εφικτών patterns (με μέγιστο πλήθος breaks)
def generate_feasible_patterns(n_rounds, max_breaks=4):
    half = n_rounds // 2
    patterns = []
    for bits in product("HA", repeat=half):
        first = ''.join(bits)
        second = complement_pattern(first)
        full = first + second
        if count_breaks(full) <= max_breaks and "HHH" not in full and "AAA" not in full:
            patterns.append(full)
    return patterns

patterns = generate_feasible_patterns(n_rounds)

print("\n=== Επανάληψη Pattern Sets μέχρι να βρεθεί εφικτό πρόγραμμα ===\n")

# Μέγιστος αριθμός προσπαθειών
max_attempts = 100
Nk = len(cosmote_teams)
successful_assignment = None
used_sets = []

start_time = time.time()
# Επανάληψη μέχρι να βρεθεί εφικτό πρόγραμμα
for attempt in range(max_attempts):
    print(f"🔁 Προσπάθεια {attempt+1}...")

    shuffled_patterns = patterns.copy()
    shuffle(shuffled_patterns)
    pattern_index = {p: i for i, p in enumerate(shuffled_patterns)}
    num_patterns = len(shuffled_patterns)

    # ----- Φάση 1: Επιλογή Patterns για COSMOTE και NOVA -----
    prob1 = pulp.LpProblem(f"Pattern_Selection_Attempt_{attempt+1}", pulp.LpMinimize)
    x = pulp.LpVariable.dicts("x", ((i, k) for i in range(num_patterns) for k in [0, 1]), cat="Binary")
    prob1 += pulp.lpSum((count_breaks(shuffled_patterns[i]) + 0.01 * random()) * x[i, k] for i in range(num_patterns) for k in [0, 1])

    for k in [0, 1]:
        for w in range(n_rounds):
            prob1 += pulp.lpSum((1 if shuffled_patterns[i][w] == 'H' else 0) * x[i, k] for i in range(num_patterns)) == Nk // 2
        prob1 += pulp.lpSum(x[i, k] for i in range(num_patterns)) == Nk

    for i, p in enumerate(shuffled_patterns):
        comp = complement_pattern(p)
        if comp in pattern_index:
            j = pattern_index[comp]
            for k in [0, 1]:
                prob1 += x[i, k] == x[j, k]

    for i in range(num_patterns):
        prob1 += pulp.lpSum(x[i, k] for k in [0, 1]) <= 1

    for prev_set in used_sets:
        prob1 += pulp.lpSum(x[i, k] for (i, k) in prev_set) <= Nk * 2 - Nk // 2

    prob1.solve()
    if pulp.LpStatus[prob1.status] != "Optimal":
        continue

    selected_cosmote = [i for i in range(num_patterns) if pulp.value(x[i, 0]) == 1]
    selected_nova = [i for i in range(num_patterns) if pulp.value(x[i, 1]) == 1]
    selected_patterns = selected_cosmote + selected_nova
    current_set = [(i, 0) for i in selected_cosmote] + [(i, 1) for i in selected_nova]
    used_sets.append(current_set)

    print("\n--- Φάση 1: Επιλογή Pattern Set ---")
    for i in selected_patterns:
        channel = "COSMOTE" if i in selected_cosmote else "NOVA"
        print(f"{i:<3} | {shuffled_patterns[i]} | Breaks: {count_breaks(shuffled_patterns[i])} | {channel}")

    # ----- Φάση 2: Χρονοδιάγραμμα μεταξύ των patterns -----
    prob2 = pulp.LpProblem("Timetable_Generation", pulp.LpMinimize)
    y = {}
    for t in range(n_rounds):
        for i in selected_patterns:
            for j in selected_patterns:
                if i != j and shuffled_patterns[i][t] == 'H' and shuffled_patterns[j][t] == 'A':
                    y[(i,j,t)] = pulp.LpVariable(f"y_{i}_{j}_{t}", cat='Binary')

    for t in range(n_rounds):
        for i in selected_patterns:
            if shuffled_patterns[i][t] == 'H':
                prob2 += pulp.lpSum(y.get((i,j,t), 0) for j in selected_patterns if j != i and shuffled_patterns[j][t] == 'A') == 1
        for j in selected_patterns:
            if shuffled_patterns[j][t] == 'A':
                prob2 += pulp.lpSum(y.get((i,j,t), 0) for i in selected_patterns if i != j and shuffled_patterns[i][t] == 'H') == 1

    # Περιορισμός: Κάθε ζευγάρι patterns παίζει ακριβώς 2 φορές (1 Home, 1 Away)
    for i in selected_patterns:
        for j in selected_patterns:
            if i < j:  # για να αποφύγουμε διπλούς ελέγχους
                prob2 += pulp.lpSum(
                    y.get((i, j, t), 0) + y.get((j, i, t), 0)
                    for t in range(n_rounds)
                ) == 2
    prob2.solve()
    if pulp.LpStatus[prob2.status] != "Optimal":
        continue

    all_teams = cosmote_teams + nova_teams
    team_to_channel = {t: 'cosmote' for t in cosmote_teams}
    team_to_channel.update({t: 'nova' for t in nova_teams})
    pattern_to_channel = {i: 'cosmote' for i in selected_cosmote}
    pattern_to_channel.update({i: 'nova' for i in selected_nova})

    print("\n--- Αναμετρήσεις ανά αγωνιστική (Pattern IDs) ---")
    for t in range(n_rounds):
        print(f"Week {t+1}:")
        for (i, j, w), var in y.items():
            if w == t and pulp.value(var) == 1:
                print(f"  Pattern {i} (H) vs Pattern {j} (A)")

    # ----- Φάση 3: Ανάθεση ομάδων στα patterns -----
    prob3 = pulp.LpProblem("Assign_Teams", pulp.LpMaximize)
    x_assign = {}
    for i in selected_patterns:
        for j, team in enumerate(all_teams):
            if pattern_to_channel[i] == team_to_channel[team]:
                x_assign[(i, j)] = pulp.LpVariable(f"x_{i}_{j}", cat='Binary')

    for i in selected_patterns:
        prob3 += pulp.lpSum(x_assign.get((i, j), 0) for j in range(len(all_teams))) == 1
    for j in range(len(all_teams)):
        prob3 += pulp.lpSum(x_assign.get((i, j), 0) for i in selected_patterns) == 1

    # Περιορισμός: Ομάδες με κοινό γήπεδο δεν παίζουν ταυτόχρονα εντός
    for team1, team2 in shared_stadium_pairs:
        j1 = all_teams.index(team1)
        j2 = all_teams.index(team2)
        for w in range(n_rounds):
            for i in selected_patterns:
                for j in selected_patterns:
                    if shuffled_patterns[i][w] == 'H' and shuffled_patterns[j][w] == 'H':
                        if pattern_to_channel[i] == team_to_channel[team1] and pattern_to_channel[j] == team_to_channel[team2]:
                            prob3 += x_assign.get((i, j1), 0) + x_assign.get((j, j2), 0) <= 1

    for i in selected_patterns:
        for j in selected_patterns:
            if i != j:
                for t in [0, n_rounds - 1]:
                    if shuffled_patterns[i][t] == 'H' and shuffled_patterns[j][t] == 'A':
                        for team1 in seeded_teams:
                            for team2 in seeded_teams:
                                if team1 != team2:
                                    if (team1, team2) in shared_stadium_pairs or (team2, team1) in shared_stadium_pairs:
                                        continue  # 👉 αγνόηση περιορισμού
                                    idx1 = all_teams.index(team1)
                                    idx2 = all_teams.index(team2)
                                    prob3 += x_assign.get((i, idx1), 0) + x_assign.get((j, idx2), 0) <= 1

    prob3.solve()
    if pulp.LpStatus[prob3.status] == "Optimal":
        elapsed_time = time.time() - start_time
        successful_assignment = {
            "assignment": {all_teams[j]: i for (i, j), var in x_assign.items() if pulp.value(var) == 1},
            "patterns": shuffled_patterns,
            "schedule": y,
            "n_rounds": n_rounds,
            "attempt": attempt + 1,
            "time": elapsed_time
        }
        break

if not successful_assignment:
    print("❌ Δεν βρέθηκε λύση μετά από 100 προσπάθειες.")
    exit()

assignment = successful_assignment["assignment"]
patterns = successful_assignment["patterns"]
y = successful_assignment["schedule"]
n_rounds = successful_assignment["n_rounds"]
pattern_to_team = {v: k for k, v in assignment.items()}

# ----- Εκτύπωση αποτελεσμάτων -----
print("\n--- Φάση 3: Ανάθεση Ομάδων ---")
for team in sorted(assignment.keys()):
    i = assignment[team]
    print(f"{team:<15} -> Pattern {i} ({shuffled_patterns[i]}) | Breaks: {count_breaks(shuffled_patterns[i])}")

print("\n--- Τελικό Πρόγραμμα ---")
matchups = set()
schedule_rows = []
for w in range(n_rounds):
    print(f"Week {w+1}:")
    for (i, j, t), var in y.items():
        if t == w and pulp.value(var) == 1:
            home = pattern_to_team[i]
            away = pattern_to_team[j]
            channel = "COSMOTE" if pattern_to_channel[i] == "cosmote" else "NOVA"
            print(f"  {home:<15} (Home) vs {away:<15} (Away)  | 📺 Κανάλι: {channel}")
            matchups.add(frozenset([home, away]))
            schedule_rows.append({
                "Αγωνιστική": w + 1,
                "Γηπεδούχος": home,
                "Φιλοξενούμενος": away
            })

print("\nBreaks ανά ομάδα:")
total_breaks = 0
has_hhh = False
for team in assignment:
    i = assignment[team]
    br = count_breaks(shuffled_patterns[i])
    if "HHH" in shuffled_patterns[i]:
        has_hhh = True
    total_breaks += br
    print(f"  {team:<15} | Breaks: {br}")
print(f"\n➡️  Συνολικά Breaks: {total_breaks} (Θεωρητικό ελάχιστο: {3*len(teams)-6})")
print(f"\n✅ Το πρόγραμμα βρέθηκε στην προσπάθεια: {successful_assignment['attempt']}")
print(f"⏱️ Χρόνος υπολογισμού: {successful_assignment['time']:.2f} δευτερόλεπτα")


# Έλεγχοι
hhh_line = f"Έχω 3 συνεχόμενα HHH; {'Ναι' if has_hhh else 'Όχι'}"
expected_pairs = len(teams) * (len(teams) - 1) // 2
matchups_line = f"Παίζουν όλες οι ομάδες μεταξύ τους; {'Ναι' if len(matchups) == expected_pairs else 'Όχι'}"
print(f"\n{hhh_line}")
print(f"{matchups_line}")

# Εξαγωγή σε Excel


week_columns = defaultdict(list)
for row in schedule_rows:
    week = f"Week {row['Αγωνιστική']}"
    match = f"{row['Γηπεδούχος']} vs {row['Φιλοξενούμενος']}"
    week_columns[week].append(match)

# Εύρεση max αριθμού αγώνων ανά εβδομάδα
max_matches = max(len(matches) for matches in week_columns.values())

# Δημιουργία DataFrame με κάθε στήλη μια αγωνιστική
schedule_table = {}
for week, matches in week_columns.items():
    schedule_table[week] = matches + [""] * (max_matches - len(matches))  # συμπλήρωση κελιών

df_pretty_schedule = pd.DataFrame(schedule_table)

# Εξαγωγή σε Excel
excel_path = "τελικό_πρόγραμμα.xlsx"
with pd.ExcelWriter(excel_path, engine='xlsxwriter') as writer:
    df_pretty_schedule.to_excel(writer, sheet_name="Πρόγραμμα", index=False)
    pd.DataFrame([[hhh_line], [matchups_line]], columns=["Έλεγχοι"]).to_excel(writer, sheet_name="Έλεγχοι", index=False)

print(f"\n📁 Το αρχείο Excel δημιουργήθηκε με ομορφότερη μορφή: {excel_path}")


# ----------------------------
# GUI εμφάνισης προγράμματος
# ----------------------------
import tkinter as tk
from tkinter import ttk

def launch_schedule_gui(schedule_rows, n_rounds, attempt_num, elapsed_time):
    root = tk.Tk()
    root.title("Τελικό Πρόγραμμα Αγώνων")

    notebook = ttk.Notebook(root)
    notebook.pack(fill='both', expand=True)

    # Δημιουργία tabs ανά εβδομάδα
    for w in range(1, n_rounds + 1):
        frame = ttk.Frame(notebook)
        notebook.add(frame, text=f"Week {w}")

        week_matches = [row for row in schedule_rows if row["Αγωνιστική"] == w]
        if not week_matches:
            ttk.Label(frame, text="Δεν υπάρχουν αγώνες").pack(pady=10)
            continue

        for match in week_matches:
            home = match['Γηπεδούχος']
            away = match['Φιλοξενούμενος']
            home_pattern = assignment[home]
            channel = "COSMOTE" if pattern_to_channel[home_pattern] == "cosmote" else "NOVA"
            label = ttk.Label(frame, text=f"{home} vs {away}  | 📺 {channel}", font=("Helvetica", 12))

            label.pack(anchor="w", padx=10, pady=2)
    
    summary_label = ttk.Label(root, text=f"✅ Βρέθηκε στην προσπάθεια {attempt_num} | ⏱️ Χρόνος: {elapsed_time:.2f} sec", font=("Helvetica", 10, "italic"))
    summary_label.pack(pady=5)
    root.mainloop()

# Ενεργοποίηση GUI
launch_schedule_gui(schedule_rows, n_rounds, successful_assignment['attempt'], successful_assignment['time'])

